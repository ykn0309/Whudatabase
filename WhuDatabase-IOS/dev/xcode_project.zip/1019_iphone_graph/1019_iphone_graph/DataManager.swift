//
//  DataManager.swift
//  0914_demo
//
//  Created by Spatialite-project on 2024/9/14.
//

import Foundation

class DataManager {
    var db: OpaquePointer?
    var graph: Graph = Graph(edges: [], nodes: [])
    
    init() {
        // 打开 SQLite 数据库
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("spatialite_graph.db")
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("Unable to open database.")
        }
        // 初始化 Spatialite
        if sqlite3_enable_load_extension(db, 1) != SQLITE_OK {
            print("Error enabling load extension")
        }
        
        if sqlite3_load_extension(db, Bundle.main.path(forResource: "mod_spatialite.8", ofType: "so"), nil, nil) != SQLITE_OK {
            print("Error loading spatialite extension")
        }
        
        let createTableSQL = """
        create table nodes(
            id integer primary key autoincrement,
            name text unique
        );
        
        create table edges(
          id integer primary key autoincrement,
          node_from integer not null,
          node_to integer not null,
          cost double not null
        );
        """
        runQuery(query: createTableSQL)
    }

    func addNode(name: String){
        let sql = "insert into nodes (name) values ('\(name)');"
        runQuery(query: sql)
    }
    
    func addEdge(node_from: String, node_to: String, cost: Int){
        if let node_from = graph.nodes.first(where: {$0.label == node_from}), let node_to = graph.nodes.first(where: {$0.label == node_to}) {
            let sql = "insert into edges (node_from, node_to, cost) values (\(node_from.id), \(node_to.id), \(cost));"
            runQuery(query: sql)
        } else {
            print("Can't find node id from node name")
        }
    }
    
    func dropTable() {
        let sql = """
        drop table nodes;
        drop table edges;
        create table nodes(
            id integer primary key autoincrement,
            name text unique
        );
        
        create table edges(
          id integer primary key autoincrement,
          node_from integer not null,
          node_to integer not null,
          cost double not null
        );
        """
        runQuery(query: sql)
        
    }
    
    func refreshGraph() ->Graph {
        dropPathTable()
        refreshNodes()
        refreshEdges()
        return graph
    }
    
    func dropPathTable() {
        let sql = """
        drop table _edges;
        drop table _edges_data;
        """
        runQuery(query: sql)
    }
    
    func refreshNodes() {
        let sql = "select * from nodes;"
        var statement: OpaquePointer?
        graph.nodes.removeAll()
        
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing select nodes statement")
        }
        while sqlite3_step(statement) == SQLITE_ROW {
            let id = Int(sqlite3_column_int(statement, 0))
            let name = String(cString: sqlite3_column_text(statement, 1))
            graph.nodes.append(Node(id: id, position: CGPoint(x: CGFloat.random(in: 0...320), y: CGFloat.random(in: 0...420)), label: name))
        }
        sqlite3_finalize(statement)
    }
    
    func refreshEdges() {
        let sql = "select * from edges;"
        var statement: OpaquePointer?
        graph.edges.removeAll()
        
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing select edges statement")
        }
        while sqlite3_step(statement) == SQLITE_ROW {
            let id = Int(sqlite3_column_int(statement, 0))
            let from_id = Int(sqlite3_column_int(statement, 1))
            let to_id = Int(sqlite3_column_int(statement, 2))
            let cost = Double(sqlite3_column_double(statement, 3))
            
            if let from: Node = graph.nodes.first(where: {$0.id == from_id}), let to: Node = graph.nodes.first(where: {$0.id == to_id}) {
                graph.edges.append(Edge(id: id, from: from, to: to, cost: cost))

            } else {
                print("Can't find from_node which id = \(from_id) or to_node which id = \(to_id)")
            }
        }
    }
    
    func shortestPath(node1: String, node2: String) -> [Edge] {
        var path: [Edge] = []
        var node_path: [Node] = []
        let createRoutingSQL = """
        select CreateRouting('_edges_data', '_edges', 'edges', 'node_from', 'node_to', NULL, 'cost', NULL, 0, 1);
        """
        runQuery(query: createRoutingSQL)
        if let node1 = graph.nodes.first(where: {$0.label == node1}), let node2 = graph.nodes.first(where: {$0.label == node2}) {
            let shortestPathSQL = """
            select * from _edges where NodeFrom = \(node1.id) and NodeTo = \(node2.id);
            """
            node_path.append(node1)
            var statement: OpaquePointer?
            if sqlite3_prepare_v2(db, shortestPathSQL, -1, &statement, nil) != SQLITE_OK {
                print("Error preparing select shortestPath1 statement")
            }
            var skip = 1
            while sqlite3_step(statement) == SQLITE_ROW {
                if skip == 1 {
                    skip = 0
                    continue
                }
                let next_node_id = Int(sqlite3_column_int(statement, 9))
                if let next_node = graph.nodes.first(where: {$0.id == next_node_id}) {
                    node_path.append(next_node)
                } else {
                    print("Can't find node from node id")
                }
            }
        } else {
            print("Can't find node id from node name")
        }
        for i in 0...node_path.count - 2 {
            let edge = Edge(id: -1, from: node_path[i], to: node_path[i+1], cost: 1)
            path.append(edge)
        }
        return path
    }
    
    func runQuery(query: String) {
        guard !query.isEmpty else {
            print("Please enter a query.")
            return
        }
        
        // 处理多个查询语句
        let queries = query.split(separator: ";").map { $0.trimmingCharacters(in: .whitespaces) }
        var resultText = ""
        
        for sql in queries {
            if !sql.isEmpty {
                resultText += "Executing query: \(sql)\n\n"
                resultText += executeQuery(sql) + "\n"
            }
        }
        
        print("\(resultText)")
    }
    
    func executeQuery(_ sql: String) -> String {
        var resultText = ""
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let columnCount = sqlite3_column_count(statement)
                for column in 0..<columnCount {
                    if let cString = sqlite3_column_text(statement, column) {
                        let value = String(cString: cString)
                        resultText += "\(value) "
                    }
                }
                resultText += "\n"
            }
            sqlite3_finalize(statement)
        } else {
            resultText = "Query failed: \(String(cString: sqlite3_errmsg(db)))"
        }
        
        return resultText
    }
    
    deinit {
        sqlite3_close(db)
    }
}
