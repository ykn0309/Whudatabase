//
//  _019_iphone_graphApp.swift
//  1019_iphone_graph
//
//  Created by Spatialite-project on 2024/10/19.
//

import SwiftUI

@main
struct _019_iphone_graphApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
