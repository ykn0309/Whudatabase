//
//  ContentView.swift
//  1019_iphone_graph
//
//  Created by Spatialite-project on 2024/10/19.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = ViewModel()
    
    var body: some View {
        Canvas { context, size in
            // Draw edges
            for edge in viewModel.graph.edges {
                let path = Path { path in
                    path.move(to: edge.from.position)
                    path.addLine(to: edge.to.position)
                }
                context.stroke(path, with: .color(.blue), lineWidth: 2)
                
                let direction = CGPoint(x: edge.to.position.x - edge.from.position.x, y: edge.to.position.y - edge.from.position.y)
                let length = sqrt(direction.x * direction.x + direction.y * direction.y)
                let unitDirection = CGPoint(x: direction.x / length, y: direction.y / length)
                let arrowOffset: CGFloat = 10
                let arrowEnd = CGPoint(
                    x: edge.to.position.x - arrowOffset * unitDirection.x,
                    y: edge.to.position.y - arrowOffset * unitDirection.y
                )
                drawArrowHead(in: context, from: edge.from.position, to: arrowEnd, length: 12, color: "b")
            }
            
            // Draw path
            for edge in viewModel.path {
                let path = Path { path in
                    path.move(to: edge.from.position)
                    path.addLine(to: edge.to.position)
                }
                context.stroke(path, with: .color(.green), lineWidth: 2)
                
                let direction = CGPoint(x: edge.to.position.x - edge.from.position.x, y: edge.to.position.y - edge.from.position.y)
                let length = sqrt(direction.x * direction.x + direction.y * direction.y)
                let unitDirection = CGPoint(x: direction.x / length, y: direction.y / length)
                let arrowOffset: CGFloat = 10
                let arrowEnd = CGPoint(
                    x: edge.to.position.x - arrowOffset * unitDirection.x,
                    y: edge.to.position.y - arrowOffset * unitDirection.y
                )
                drawArrowHead(in: context, from: edge.from.position, to: arrowEnd, length: 12, color: "g")
            }
            // Draw nodes and labels
            
            for node in viewModel.graph.nodes {
                let circle = Path(ellipseIn: CGRect(x: node.position.x - 10, y: node.position.y - 10, width: 20, height: 20))
                context.fill(circle, with: .color(.red))
                context.draw(Text(node.label).font(.caption).foregroundColor(.white), at: node.position)
            }
        }.onAppear(perform: {
            viewModel.refreshGraph()
        })
        .padding()
        VStack{
            HStack{
                Button(action: {
                    viewModel.cleanCanvas()
                }, label: {
                    Text("Clean")
                }).padding()
                Button(action: {
                    viewModel.refreshGraph()
                }, label: {
                    Text("Refresh Position")
                }).padding()
            }
            HStack{
                Text("New Node")
                TextField("node name", text: $viewModel.new_node)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Button(action: {
                    viewModel.addNode()
                }, label: {
                    Text("Add")
                })
            }
            .padding()
            HStack{
                Text("Node1")
                TextField("node1 name", text: $viewModel.node1)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Text("Node2")
                TextField("node2 name", text: $viewModel.node2)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
            }
            .padding()
            HStack{
                Button(action: {
                    viewModel.addEdge()
                }) {
                    Text("Add Edge")
                }.padding()
                Button(action: {
                    viewModel.shortestPath()
                }) {
                    Text("Shortest Path")
                }.padding()
            }
        }
    }
    
    private func drawArrowHead(in context: GraphicsContext, from start: CGPoint, to end: CGPoint, length: CGFloat, color: String) {
        let angle = atan2(end.y - start.y, end.x - start.x)
        
        let arrowPath = Path { path in
            path.move(to: end)
            path.addLine(to: CGPoint(x: end.x - length * cos(angle - .pi / 6), y: end.y - length * sin(angle - .pi / 6)))
            path.addLine(to: CGPoint(x: end.x - length * cos(angle + .pi / 6), y: end.y - length * sin(angle + .pi / 6)))
            path.closeSubpath()
        }
        if color == "b"{
            context.fill(arrowPath, with: .color(.blue))
        } else if color == "g"{
            context.fill(arrowPath, with: .color(.green))
        }
    }
}

class ViewModel: ObservableObject {
    private var dataManager = DataManager()
    
    @Published var graph: Graph = Graph(edges: [], nodes: [])
    @Published var new_node: String = ""
    @Published var node1: String = ""
    @Published var node2: String = ""
    @Published var path: [Edge] = []
    
    func refreshGraph() {
        path = []
        graph = dataManager.refreshGraph()
    }
    
    func addNode() {
        dataManager.addNode(name: new_node)
        refreshGraph()
//        runForceDirectedLayout()
    }
    
    func addEdge() {
        dataManager.addEdge(node_from: node1, node_to: node2, cost: 1)
        refreshGraph()
//        runForceDirectedLayout()
    }
    
    func cleanCanvas() {
        dataManager.dropTable()
        refreshGraph()
    }
    
    func shortestPath() {
        path = dataManager.shortestPath(node1: node1, node2: node2)
    }
    
//    func runForceDirectedLayout() {
//        let width = UIScreen.main.bounds.width
//        let height = UIScreen.main.bounds.height
//
//        // Create a mutable copy of nodes
//        var updatedNodes = graph.nodes
//        for _ in 0..<500 {
//            // Calculate repulsion forces
//            for i in updatedNodes.indices {
//                for j in updatedNodes.indices where i != j {
//                    let dx = updatedNodes[j].position.x - updatedNodes[i].position.x
//                    let dy = updatedNodes[j].position.y - updatedNodes[i].position.y
//                    let distance = sqrt(dx * dx + dy * dy)
//                    let force = (distance - 50) / distance
//                    updatedNodes[i].position.x += dx * force * 0.1
//                    updatedNodes[i].position.y += dy * force * 0.1
//                }
//            }
//
//            // Calculate attraction forces
//            for edge in graph.edges {
//                if let fromIndex = updatedNodes.firstIndex(where: { $0.id == edge.from.id }),
//                   let toIndex = updatedNodes.firstIndex(where: { $0.id == edge.to.id }) {
//
//                    let dx = updatedNodes[toIndex].position.x - updatedNodes[fromIndex].position.x
//                    let dy = updatedNodes[toIndex].position.y - updatedNodes[fromIndex].position.y
//                    let distance = sqrt(dx * dx + dy * dy)
//                    let force = (distance - 100) / distance
//
//                    updatedNodes[fromIndex].position.x += dx * force * 0.1
//                    updatedNodes[fromIndex].position.y += dy * force * 0.1
//                    updatedNodes[toIndex].position.x -= dx * force * 0.1
//                    updatedNodes[toIndex].position.y -= dy * force * 0.1
//                }
//            }
//
//            // Boundaries
//            for i in updatedNodes.indices {
//                updatedNodes[i].position.x = max(10, min(width - 10, updatedNodes[i].position.x))
//                updatedNodes[i].position.y = max(10, min(height - 10, updatedNodes[i].position.y))
//            }
//        }
//        // Update the state with new node positions
//        graph.nodes = updatedNodes
//    }
}

#Preview {
    ContentView()
}

