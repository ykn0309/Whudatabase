//
//  graph.swift
//  0914_demo
//
//  Created by Spatialite-project on 2024/9/14.
//

import Foundation

struct Node: Equatable, Identifiable {
    let id: Int
    var position: CGPoint
    let label: String
}

struct Edge: Equatable {
    let id: Int
    let from: Node
    let to: Node
    let cost: Double
}

struct Graph: Equatable{
    var edges: [Edge]
    var nodes: [Node]
}
