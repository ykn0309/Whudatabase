//
//  bridge.h
//  0914_demo
//
//  Created by Spatialite-project on 2024/9/14.
//

#ifndef bridge_h
#define bridge_h

# import "sqlite3.h"

#endif /* bridge_h */
