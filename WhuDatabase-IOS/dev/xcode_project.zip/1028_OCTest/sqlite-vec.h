#ifndef SQLITE_VEC_H
#define SQLITE_VEC_H

int sqlite3_vec_init(sqlite3 *db, char **pzErrMsg,
                  const sqlite3_api_routines *pApi);

#endif /* ifndef SQLITE_VEC_H */
