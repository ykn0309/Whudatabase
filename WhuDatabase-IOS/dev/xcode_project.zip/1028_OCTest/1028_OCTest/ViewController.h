//
//  ViewController.h
//  1028_OCTest
//
//  Created by Spatialite-project on 2024/10/28.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *sqlInputField;
@property (weak, nonatomic) IBOutlet UITextView *resultTextView;

- (IBAction)runQuery:(id)sender;

@end
