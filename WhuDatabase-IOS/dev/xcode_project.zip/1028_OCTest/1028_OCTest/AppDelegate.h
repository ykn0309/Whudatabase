//
//  AppDelegate.h
//  1028_OCTest
//
//  Created by Spatialite-project on 2024/10/28.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

