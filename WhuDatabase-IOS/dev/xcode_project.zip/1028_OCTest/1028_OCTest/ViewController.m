//
//  ViewController.m
//  1028_OCTest
//
//  Created by Spatialite-project on 2024/10/28.
//

#import "ViewController.h"
#import "sqlite3.h"
#import "sqlite-vec.h"

@interface ViewController () {
    sqlite3 *db;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSError *error = nil;
    NSURL *documentsDirectory = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:&error];

    if (error) {
        // 处理错误
        NSLog(@"Error getting documents directory: %@", error);
    } else {
        NSURL *fileURL = [documentsDirectory URLByAppendingPathComponent:@"whudatabase.db"];
        // 打开数据库
        if (sqlite3_open([fileURL.path UTF8String], &db) != SQLITE_OK) {
            NSLog(@"Failed to open database");
            return;
        }
    }
    
    // 加载扩展
    NSString *extensionPath = [[NSBundle mainBundle] pathForResource:@"mod_spatialite" ofType:@"dylib"];
    if (![self loadSQLiteExtension:extensionPath]) {
        return;
    }
//    extensionPath = [[NSBundle mainBundle] pathForResource:@"vec0" ofType:@"dylib"];
//    if (![self loadSQLiteExtension:extensionPath]) {
//        return;
//    }
    if (sqlite3_vec_init(db, NULL, NULL)!= SQLITE_OK) {
        NSLog(@"Failed to init vec");
    }}

- (BOOL)loadSQLiteExtension:(NSString *)extensionPath {
    if (sqlite3_enable_load_extension(db, 1) != SQLITE_OK) {
        NSLog(@"Failed to enable extension loading: %s", sqlite3_errmsg(db));
        return NO;
    }

    if (sqlite3_load_extension(db, [extensionPath UTF8String], NULL, NULL) != SQLITE_OK) {
        NSLog(@"Failed to load extension.");
        return NO;
    }

    NSLog(@"Extension loaded successfully");
    return YES;
}

- (IBAction)runQuery:(id)sender {
    NSString *query = self.sqlInputField.text;
    NSArray *queries = [query componentsSeparatedByString:@";"]; // 以分号分隔多个查询
    NSMutableString *finalResult = [NSMutableString string];

    for (NSString *sql in queries) {
        NSString *trimmedSQL = [sql stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (trimmedSQL.length > 0) {
            NSString *result = [self executeQuery:trimmedSQL]; // 调用 executeQuery 并获取结果
            [finalResult appendString:result]; // 将每个结果累加
        }
    }

    self.resultTextView.text = finalResult; // 更新文本视图
}


- (NSString *)executeQuery:(NSString *)sql {
    sqlite3_stmt *statement;
    NSMutableString *result = [NSMutableString string];

    if (sqlite3_prepare_v2(db, [sql UTF8String], -1, &statement, NULL) == SQLITE_OK) {
        while (sqlite3_step(statement) == SQLITE_ROW) {
            int columnCount = sqlite3_column_count(statement);
            for (int i = 0; i < columnCount; i++) {
                const char *columnText = (const char *)sqlite3_column_text(statement, i);
                if (columnText) {
                    [result appendFormat:@"%s\t", columnText];
                }
            }
            [result appendString:@"\n"];
        }
        [result appendString:@"OK\n"];
    } else {
        NSLog(@"Failed to prepare query: %s", sqlite3_errmsg(db));
        [result appendFormat:@"Error: %s\n", sqlite3_errmsg(db)];
    }

    sqlite3_finalize(statement);
    return result; // 返回查询结果
}


- (void)dealloc {
    sqlite3_close(db);
}

@end
