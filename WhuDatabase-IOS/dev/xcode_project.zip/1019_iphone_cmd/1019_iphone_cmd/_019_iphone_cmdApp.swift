//
//  _019_iphone_cmdApp.swift
//  1019_iphone_cmd
//
//  Created by Spatialite-project on 2024/10/19.
//

import SwiftUI

@main
struct _019_iphone_cmdApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
