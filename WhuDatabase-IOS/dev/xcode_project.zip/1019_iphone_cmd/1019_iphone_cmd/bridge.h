//
//  bridge.h
//  1019_iphone_cmd
//
//  Created by Spatialite-project on 2024/10/19.
//

#ifndef bridge_h
#define bridge_h

#import "sqlite3.h"

#endif /* bridge_h */
