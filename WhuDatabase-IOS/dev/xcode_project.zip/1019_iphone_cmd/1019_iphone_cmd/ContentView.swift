//
//  ContentView.swift
//  1019_iphone_cmd
//
//  Created by Spatialite-project on 2024/10/19.
//

import SwiftUI

// 视图模型
class SQLiteViewModel: ObservableObject {
    @Published var query: String = ""
    @Published var result: String = ""
    
    var db: OpaquePointer?
    
    init() {
        // 打开 SQLite 数据库
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("spatialite.db")
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            result = "Unable to open database."
        }
        // 初始化 Spatialite
        if sqlite3_enable_load_extension(db, 1) != SQLITE_OK {
            print("Error enabling load extension")
        }

        if sqlite3_load_extension(db, Bundle.main.path(forResource: "mod_spatialite.8", ofType: "so"), nil, nil) != SQLITE_OK {
            print("Error loading spatialite extension")
        }
    }
    
    func load_spatialite() {
        
    }

    func runQuery() {
        guard !query.isEmpty else {
            result = "Please enter a query."
            return
        }
        
        // 处理多个查询语句
        let queries = query.split(separator: ";").map { $0.trimmingCharacters(in: .whitespaces) }
        var resultText = ""
        
        for sql in queries {
            if !sql.isEmpty {
                resultText += "Executing query: \(sql)\n\n"
                resultText += executeQuery(sql) + "\n"
            }
        }
        
        result = resultText
    }
    
    func executeQuery(_ sql: String) -> String {
        var resultText = ""
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let columnCount = sqlite3_column_count(statement)
                for column in 0..<columnCount {
                    if let cString = sqlite3_column_text(statement, column) {
                        let value = String(cString: cString)
                        resultText += "\(value) "
                    }
                }
                resultText += "\n"
            }
            sqlite3_finalize(statement)
        } else {
            resultText = "Query failed: \(String(cString: sqlite3_errmsg(db)))"
        }
        
        return resultText
    }
    
    deinit {
        sqlite3_close(db)
    }
}

// SwiftUI 视图
struct ContentView: View {
    @StateObject private var viewModel = SQLiteViewModel()
    
    var body: some View {
        VStack {
            TextField("Enter SQL query", text: $viewModel.query)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button("Run Query") {
                viewModel.runQuery()
            }
            .padding()
            
            ScrollView {
                Text(viewModel.result)
                    .padding()
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

