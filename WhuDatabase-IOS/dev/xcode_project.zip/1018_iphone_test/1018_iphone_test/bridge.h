//
//  bridge.h
//  1018_iphone_test
//
//  Created by Spatialite-project on 2024/10/18.
//

#ifndef bridge_h
#define bridge_h

#import "sqlite3.h"

#endif /* bridge_h */
