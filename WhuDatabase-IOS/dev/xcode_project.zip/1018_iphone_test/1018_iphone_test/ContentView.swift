//
//  ContentView.swift
//  1018_iphone_test
//
//  Created by Spatialite-project on 2024/10/18.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = ViewModel()
    var body: some View {
        NavigationView(content: {
            VStack {
                Image("logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                    .padding()
                Text("sqlite-vec test")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                NavigationLink(destination: NormalizationView()) { Text("Normalization") }.padding()
                NavigationLink(destination: AddSubView()) { Text("Add & Sub") }.padding()
                NavigationLink(destination: DistanceView()) { Text("Distance") }.padding()
                NavigationLink(destination: KNNView()) {
                    Text("KNN") }.padding()
            }
        })
        
    }
}

struct NormalizationView: View {
    @StateObject private var viewModel = ViewModel()
    var body: some View {
        VStack {
            Text("Normalization")
                .font(.title)
                .fontWeight(.bold)
            HStack {
                Text("Vector")
                TextField("Please input vector", text: $viewModel.vec1)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding()
            Button(action: {viewModel.normalization()}, label: {
                Text("Normalize")
            })
            ScrollView {
                Text(viewModel.result).padding()
            }
        }
    }
}

struct AddSubView: View {
    @StateObject private var viewModel = ViewModel()
    var body: some View {
        VStack {
            Text("Add & Sub")
                .font(.title)
                .fontWeight(.bold)
            HStack {
                Text("Vector1")
                TextField("Please input vector1", text: $viewModel.vec1)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding()
            HStack {
                Text("Vector2")
                TextField("Please input vector2", text: $viewModel.vec2)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding()
        }.padding()
        HStack {
            Button(action: {viewModel.add()}, label: {
                Text("Add")
            }).padding()
            Button(action: {viewModel.sub()}, label: {
                Text("Sub")
            }).padding()
        }
        ScrollView {
            Text(viewModel.result).padding()
        }
    }
}

struct DistanceView: View {
    @StateObject private var viewModel = ViewModel()
    var body: some View {
        VStack {
            Text("Distance")
                .font(.title)
                .fontWeight(.bold)
            HStack {
                Text("Vector1")
                TextField("Please input vector1", text: $viewModel.vec1)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding()
            HStack {
                Text("Vector2")
                TextField("Please input vector2", text: $viewModel.vec2)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding()
        }.padding()
        HStack {
            Button(action: {viewModel.distance_l2()}, label: {
                Text("Euclidian Distance")
            }).padding()
            Button(action: {viewModel.distance_cosine()}, label: {
                Text("Cosine Distance")
            }).padding()
        }
        ScrollView {
            Text(viewModel.result).padding()
        }
    }
}

struct KNNView: View {
    @StateObject private var viewModel = ViewModel()
    var body: some View {
        VStack{
            Text("KNN")
            HStack {
                TextField("Please input vector", text: $viewModel.vec1)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                Picker("Select K", selection: $viewModel.k){
                    ForEach(1..<5) { number in
                        Text("\(number)").tag(number)
                    }
                }
                .pickerStyle(WheelPickerStyle())
                .frame(width: 100.0)
                Button(action: {viewModel.knn()}, label: {
                    Text("KNN")
                }).padding()
            }
            List(viewModel.result_list) { item in
                HStack {
                    Text(item.vec).padding()
                    if item.distance != -1 {
                        Text("\(item.distance)").padding()
                    }
                }
            }.onAppear(perform: {
                viewModel.vecList()
            })
        }
    }
}

class ViewModel: ObservableObject {
    private var dataManager = DataManager()
    
    @Published var vec1: String = ""
    @Published var vec2: String = ""
    @Published var k:Int = 1
    @Published var result: String = ""
    @Published var result_list: [Vector] = []
    
    func normalization() {
        result = dataManager.normalize(vec: vec1)
    }
    
    func add() {
        result = dataManager.add(vec1: vec1, vec2: vec2)
    }
    
    func sub() {
        result = dataManager.sub(vec1: vec1, vec2: vec2)
    }
    
    func distance_l2() {
        result = dataManager.distance(vec1: vec1, vec2: vec2, type: 0)
    }
    
    func distance_cosine() {
        result = dataManager.distance(vec1: vec1, vec2: vec2, type: 1)
    }
    
    func knn() {
        result_list = dataManager.knn(vec: vec1, limit: k)
    }
    
    func vecList() {
        result_list = dataManager.vecList()
    }
}

#Preview {
    ContentView()
}
