//
//  DataManager.swift
//  1018_iphone_test
//
//  Created by Spatialite-project on 2024/10/18.
//

import Foundation
import Combine

struct Vector: Identifiable{
    let id = UUID()
    var rowid: Int
    var vec: String
    var distance: Double
}

class DataManager {
    var db: OpaquePointer?
    
    init() {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("sqlitevec.db")
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("Unable to open database.")
        }
        // 初始化 Spatialite
        if sqlite3_enable_load_extension(db, 1) != SQLITE_OK {
            print("Error enabling load extension")
        }
        if let vec0Path = Bundle.main.path(forResource: "vec0", ofType: "dylib"){
            let rc = sqlite3_load_extension(db, vec0Path, nil, nil)
            if rc != SQLITE_OK {
                print("Error loading sqlite-vec extension")
            } else {
                createVectorVtable()
            }
        } else {
            print("vec0.dylib not found")
        }
    }
    
    func normalize(vec: String) -> String {
        let sql = "select vec_to_json(vec_normalize('[\(vec)]'));"
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_step(statement) == SQLITE_ROW {
                if let cstring = sqlite3_column_text(statement, 0) {
                    let result = String(cString: cstring)
                    return result
                } else {
                    print("Error sqlite3_column_text in normalize()")
                }
            }
        } else {
            print("Query failed: \(String(cString: sqlite3_errmsg(db)))")
        }
        return "Normalization Error"
    }
    
    func add(vec1: String, vec2: String) -> String {
        let sql = """
        select vec_to_json(
            vec_add(
                '[\(vec1)]',
                '[\(vec2)]'
            )
        );
        """
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_step(statement) == SQLITE_ROW {
                if let cstring = sqlite3_column_text(statement, 0) {
                    let result = String(cString: cstring)
                    return result
                } else {
                    print("Error sqlite3_column_text in add()")
                }
            }
        } else {
            print("Query failed: \(String(cString: sqlite3_errmsg(db)))")
        }
        return "Add Error"
    }
    
    func sub(vec1: String, vec2: String) -> String {
        let sql = """
        select vec_to_json(
            vec_sub(
                '[\(vec1)]',
                '[\(vec2)]'
            )
        );
        """
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_step(statement) == SQLITE_ROW {
                if let cstring = sqlite3_column_text(statement, 0) {
                    let result = String(cString: cstring)
                    return result
                } else {
                    print("Error sqlite3_column_text in sub()")
                }
            }
        } else {
            print("Query failed: \(String(cString: sqlite3_errmsg(db)))")
        }
        return "Sub Error"
    }
    
    func distance(vec1: String, vec2: String, type: Int) -> String {
        var t = ""
        if type == 0 {
            t = "L2"
        } else {
            t = "cosine"
        }
        
        let sql = """
        select vec_distance_\(t)(
            '[\(vec1)]',
            '[\(vec2)]'
        );
        """
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_step(statement) == SQLITE_ROW {
                if let cstring = sqlite3_column_text(statement, 0) {
                    let result = String(cString: cstring)
                    return result
                } else {
                    print("Error sqlite3_column_text in distance()")
                }
            }
        } else {
            print("Query failed: \(String(cString: sqlite3_errmsg(db)))")
        }
        return "Distance Error"
    }
    
    func createVectorVtable() {
        let sql = """
        create virtual table if not exists vecs using vec0(sample_embedding float[8]);
        """
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_step(statement) == SQLITE_DONE {
                print("Create virtual table successfully")
                insertVector()
            } else {
                print("Create virtual table failed \(String(cString: sqlite3_errmsg(db)))")
            }
        }
        sqlite3_finalize(statement)
    }
    
    func insertVector() {
        let sql = """
        insert into vecs(rowid, sample_embedding)
          values
            (1, '[-0.200, 0.250, 0.341, -0.211, 0.645, 0.935, -0.316, -0.924]'),
            (2, '[0.443, -0.501, 0.355, -0.771, 0.707, -0.708, -0.185, 0.362]'),
            (3, '[0.716, -0.927, 0.134, 0.052, -0.669, 0.793, -0.634, -0.162]'),
            (4, '[-0.710, 0.330, 0.656, 0.041, -0.990, 0.726, 0.385, -0.958]');
        """
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_step(statement) == SQLITE_DONE {
                print("Insert vectors successfully")
            } else {
                print("Insert vectors failed")
            }
        }
        sqlite3_finalize(statement)
    }
    
    func knn(vec: String, limit: Int) -> [Vector] {
        let sql = """
        select
          rowid,
          vec_to_json(sample_embedding),
          distance
        from vecs
        where sample_embedding match '[\(vec)]'
        order by distance
        limit \(limit);
        """
        var vec_list: [Vector] = []
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                var vector = Vector(rowid: -1, vec: "", distance: -1)
                let rid = sqlite3_column_int(statement, 0)
                let distance = sqlite3_column_double(statement, 2)
                if let vec = sqlite3_column_text(statement, 1) {
                    vector.vec = String(cString: vec)
                    vector.rowid = Int(rid)
                    vector.distance = distance
                }
                vec_list.append(vector)
            }
        } else {
            print("\(String(cString: sqlite3_errmsg(statement)))")
        }
        sqlite3_finalize(statement)
        return vec_list
    }
    
    func vecList() -> [Vector] {
        let sql = """
        select rowid, vec_to_json(sample_embedding) from vecs;
        """
        var vec_list: [Vector] = []
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                var vector = Vector(rowid: -1, vec: "", distance: -1)
                let rid = sqlite3_column_int(statement, 0)
                if let vec = sqlite3_column_text(statement, 1) {
                    vector.rowid = Int(rid)
                    vector.vec = String(cString: vec)
                }
                vec_list.append(vector)
            }
        }
        sqlite3_finalize(statement)
        return vec_list
    }
}

