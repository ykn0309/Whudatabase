//
//  _018_iphone_testApp.swift
//  1018_iphone_test
//
//  Created by Spatialite-project on 2024/10/18.
//

import SwiftUI

@main
struct _018_iphone_testApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
