/* ./config-msvc.h.  Generated from config-msvc.h.in by configure.  */
/* ./config-msvc.h.in - manually maintained */

/* Must be =64 in order to enable huge-file support. */
#define _FILE_OFFSET_BITS 64

/* Must be defined in order to enable huge-file support. */
#define _LARGEFILE_SOURCE 1

/* Must be defined in order to enable huge-file support. */
#define _LARGE_FILE 1

/* includes gaiaconfig-msvc.h */
#include "./src/headers/spatialite/gaiaconfig-msvc.h"
