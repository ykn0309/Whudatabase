/* ./src/headers/spatialite/gaiaconfig.h.  Generated from gaiaconfig.h.in by configure.  */
/* ./src/headers/spatialite/gaiaconfig.h.in - manually maintained */

/* Should be defined in order to enable GCP support. */
/* #undef ENABLE_GCP */

/* Should be defined in order to enable GeoPackage support. */
#define ENABLE_GEOPACKAGE 1

/* Should be defined in order to enable LIBXML2 support. */
#define ENABLE_LIBXML2 1

/* Should be defined in order to enable MiniZIP support. */
/* #undef ENABLE_MINIZIP */

/* Should be defined in order to enable RTTOPO support. */
/* #undef ENABLE_RTTOPO */

/* Should be defined in order to enable GEOS_370 support. */
/* #undef GEOS_370 */

/* Should be defined in order to enable GEOS_3100 support. */
/* #undef GEOS_3100 */

/* Should be defined in order to enable GEOS_3110 support. */
/* #undef GEOS_3110 */

/* Should be defined in order to enable GEOS_ADVANCED support. */
/* #undef GEOS_ADVANCED */

/* Should be defined in order to fully disable GEOS non-thread-safe API. */
/* #undef GEOS_ONLY_REENTRANT */

/* Should be defined in order to enable GEOS_REENTRANT (fully thread-safe). */
/* #undef GEOS_REENTRANT */

/* Should be defined in order to disable EPSG full support. */
/* #undef OMIT_EPSG */

/* Should be defined in order to disable FREEXL support. */
#define OMIT_FREEXL 1

/* Should be defined in order to disable GEOCALLBACKS support. */
/* #undef OMIT_GEOCALLBACKS */

/* Should be defined in order to disable GEOS support. */
#define OMIT_GEOS 1

/* Should be defined in order to disable ICONV support. */
/* #undef OMIT_ICONV */

/* Should be defined in order to disable KNN support. */
/* #undef OMIT_KNN */

/* Should be defined in order to disable MATHSQL support. */
/* #undef OMIT_MATHSQL */

/* Should be defined in order to disable PROJ.4 support. */
#define OMIT_PROJ 1

/* Should be defined in order to enable PROJ.6 support. */
/* #undef PROJ_NEW */

/* Should contain a text-string describing the intended target CPU */
#define SPATIALITE_TARGET_CPU "arm64-apple-darwin23.6.0"

/* the Version of this package */
#define SPATIALITE_VERSION "5.1.0"
